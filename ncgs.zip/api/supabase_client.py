from dotenv import load_dotenv
from supabase import create_client
import os

load_dotenv()

url = f"https://{os.getenv('SUPABASE_PROJECT_ID')}.supabase.co"
key = os.getenv("SUPABASE_API_KEY")

if not os.getenv("SUPABASE_PROJECT_ID") or not key:
    raise RuntimeError(
        "SUPABASE_PROJECT_ID and SUPABASE_API_KEY must be set (check your .env file)"
    )

supabase = create_client(url, key)